from django.urls import path
from .views import index, create, show, show_employee, edit, delete_employee

urlpatterns = [
    path('', index, name='index'),  
    path('create/', create, name='create'),
    path('show/', show, name='show'),
    path('show/<int:id>/', show_employee, name='show_employee'),
    path('edit/<int:id>/', edit, name='edit'),
    path('delete/<int:employee_id>/', delete_employee, name='delete_employee'),
]
