from django.shortcuts import render , get_object_or_404
from django.http import HttpResponse
from myapp.models import Employee 
from django.core.files.storage import FileSystemStorage


def index(request):
    data=Employee.objects.all()
    return render(request, 'index.html',{'data':data})

from django.shortcuts import render, redirect
from .models import Employee  
from .forms import EmployeeForm  

def create(request):
    if request.method == "POST":
        form = EmployeeForm(request.POST, request.FILES)  
        if form.is_valid():
            form.save()
            return redirect('/') 
    else:
        form = EmployeeForm()  

    return render(request, 'create.html', {'form': form})



def show(request):
    employees = Employee.objects.all()  
    return render(request, 'show.html', {'employees': employees})

def show_employee(request, id):
    employee = get_object_or_404(Employee, id=id)  # Fetch the employee by ID
    return render(request, 'show_employee.html', {'employee': employee})

def edit(request, id):
    employee = get_object_or_404(Employee, id=id)

    if request.method == 'POST':
        employee.name = request.POST['name']
        employee.position = request.POST['position']
        employee.department = request.POST['department']
        employee.salary = request.POST['salary']
        employee.save()
        return redirect('/')

    return render(request, 'edit_employee.html', {'employee': employee})  

def delete_employee(request, employee_id):
    employee = Employee.objects.get(id=employee_id)

    
    employee.delete()
    return redirect('/')

 
